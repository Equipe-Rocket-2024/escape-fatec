class Item {
  final String name;
  final String description;
  final String imagePath;
  double posX;
  double posY;
  bool inInventory; // Caminho da imagem do item, se aplicável

  Item({
    required this.name,
    this.description = '', // Por padrão, não há imagem
    this.imagePath = '',
    required this.posX,
    required this.posY,
    this.inInventory = false,
  });
}

List<Item> items = [
        Item(name: 'Chave', description: 'Uma chave? Será que possui alguma utilidade?', imagePath: 'assets/images/chave.png', posX: 50.0, posY: 495.0, inInventory: false), //0
        Item(name: 'Frasco', description: 'Um frasco... de luminol?', imagePath: 'assets/images/frasco.webp', posX: 230, posY: 310, inInventory: false), //0
        Item(name: 'Sagitário', description: 'Minha avó era de sagitário!', imagePath: 'assets/images/sagitario.webp', posX: 400, posY: 400, inInventory: false),
];

void addItem(Item item){
  items.add(item);
  item.inInventory = true;
}