// door.dart
class Door {
  final String name;
  bool locked;

  Door({required this.name, this.locked = true});
}
