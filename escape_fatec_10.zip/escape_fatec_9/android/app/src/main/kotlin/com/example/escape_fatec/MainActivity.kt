package com.example.escape_fatec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
